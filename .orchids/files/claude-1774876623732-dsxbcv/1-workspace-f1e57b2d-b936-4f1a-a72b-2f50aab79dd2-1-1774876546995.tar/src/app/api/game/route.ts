import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Prize pool with weights
const PRIZE_POOL = [
  { id: 'sheep',  weight: 1,  won: true,  name: 'خروف', emoji: '🐑' },
  { id: 'gift',   weight: 4,  won: true,  name: 'هدية', emoji: '🎁' },
  { id: 'coffee', weight: 10, won: true,  name: 'قهوة', emoji: '☕' },
  { id: 'sweets', weight: 20, won: true,  name: 'حلوى', emoji: '🍬' },
  { id: 'nothing', weight: 65, won: false, name: 'لا شيء', emoji: '💨' },
];

function pickPrize() {
  const totalWeight = PRIZE_POOL.reduce((sum, p) => sum + p.weight, 0);
  let random = Math.random() * totalWeight;
  for (const prize of PRIZE_POOL) {
    random -= prize.weight;
    if (random <= 0) return prize;
  }
  return PRIZE_POOL[PRIZE_POOL.length - 1];
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { phone } = body;

    if (!phone) {
      return NextResponse.json(
        { error: 'الرجاء إدخال رقم الهاتف' },
        { status: 400 }
      );
    }

    // Validate phone: exactly 8 digits (e.g. "22113344")
    if (!/^\d{8}$/.test(phone)) {
      return NextResponse.json(
        { error: 'رقم الهاتف غير صحيح (8 أرقام)' },
        { status: 400 }
      );
    }

    // Check if phone already participated
    const existing = await db.participation.findUnique({
      where: { phone },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'لقد شاركت بالفعل!', alreadyPlayed: true, prize: PRIZE_POOL.find(p => p.id === existing.prize) },
        { status: 409 }
      );
    }

    // Determine prize
    const prize = pickPrize();

    // Save participation
    await db.participation.create({
      data: {
        phone,
        prize: prize.id,
        won: prize.won,
      },
    });

    return NextResponse.json({
      success: true,
      prize: {
        id: prize.id,
        name: prize.name,
        emoji: prize.emoji,
        won: prize.won,
      },
    });
  } catch (error) {
    console.error('Game API error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ. حاول مرة أخرى.' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const participations = await db.participation.count();
    const winners = await db.participation.count({ where: { won: true } });

    return NextResponse.json({
      totalParticipations: participations,
      totalWinners: winners,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    );
  }
}
