'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import CardStrip, { PRIZES, type PrizeDef } from '@/components/game/CardStrip';
import Confetti from '@/components/game/Confetti';
import { playWinSound, playLoseSound, initAudio } from '@/lib/audio';

// ── Prize info for result display ─────────────────────
function getPrizeInfo(prize: PrizeDef) {
  switch (prize.id) {
    case 'sheep':
      return {
        title: '🎉 مبروك! ربحت خروف!',
        subtitle: 'خروف ضحية سمين في انتظارك',
        description: 'سيتم التواصل معك عبر الهاتف لتسليم الجائزة',
        isBigWin: true,
      };
    case 'gift':
      return {
        title: '🎊 مبروك! ربحت هدية!',
        subtitle: 'هدية ثمينة في انتظارك',
        description: 'سيتم التواصل معك عبر الهاتف لتسليم الجائزة',
        isBigWin: true,
      };
    case 'coffee':
      return {
        title: '☕ أحسنت! ربحت قهوة!',
        subtitle: 'استمتع بقهوة على حسابنا',
        description: 'سيتم التواصل معك لتسليم الجائزة',
        isBigWin: false,
      };
    case 'sweets':
      return {
        title: '🍬 ربحت حلوى!',
        subtitle: 'حلويات لذيذة في انتظارك',
        description: 'سيتم التواصل معك لتسليم الجائزة',
        isBigWin: false,
      };
    default:
      return {
        title: '💨 حظ أوفر!',
        subtitle: 'لم تربح هذه المرة',
        description: 'حاول مرة أخرى! قد يكون حظك أوفر المرة القادمة',
        isBigWin: false,
      };
  }
}

// ── Countdown to Eid ──────────────────────────────────
function useEidCountdown() {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const target = new Date('2025-06-07T00:00:00+01:00');

    const update = () => {
      const now = new Date();
      const diff = target.getTime() - now.getTime();
      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / (1000 * 60)) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      });
    };

    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  return { timeLeft };
}

// ── Decorative stars ──────────────────────────────────
function DecorativeStars() {
  const stars = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 2 + Math.random() * 4,
    delay: Math.random() * 5,
    duration: 2 + Math.random() * 3,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute rounded-full star-twinkle"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            backgroundColor: 'rgba(255, 215, 0, 0.4)',
            boxShadow: '0 0 4px rgba(255, 215, 0, 0.3)',
            '--delay': `${star.delay}s`,
            '--duration': `${star.duration}s`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────
export default function Home() {
  const [phase, setPhase] = useState<'form' | 'loading' | 'spinning' | 'revealing' | 'result'>('form');
  const [phone, setPhone] = useState('');
  const [targetPrize, setTargetPrize] = useState<PrizeDef>(PRIZES[PRIZES.length - 1]);
  const [error, setError] = useState('');
  const [showConfetti, setShowConfetti] = useState(false);
  const [qrCode, setQrCode] = useState<string>('');
  const [stats, setStats] = useState<{ total: number; winners: number } | null>(null);
  const qrFetchedRef = useRef(false);
  const phoneInputRef = useRef<HTMLInputElement>(null);

  const { timeLeft } = useEidCountdown();

  // Fetch stats
  useEffect(() => {
    fetch('/api/game')
      .then(res => res.json())
      .then(data => setStats({ total: data.totalParticipations || 0, winners: data.totalWinners || 0 }))
      .catch(() => {});
  }, []);

  // Fetch QR code
  useEffect(() => {
    if (phase === 'result' && !qrFetchedRef.current) {
      qrFetchedRef.current = true;
      fetch('/api/qr')
        .then(res => res.json())
        .then(data => {
          if (data.qr) setQrCode(data.qr);
        })
        .catch(() => {});
    }
  }, [phase]);

  const handleSubmit = useCallback(async () => {
    setError('');

    // Validate phone: exactly 8 digits
    if (!/^\d{8}$/.test(phone)) {
      setError('أدخل رقم هاتف صحيح (8 أرقام مثل 22113344)');
      return;
    }

    setPhase('loading');
    initAudio();

    try {
      const res = await fetch('/api/game', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.alreadyPlayed && data.prize) {
          // They already played — show them their previous result
          const prize = PRIZES.find(p => p.id === data.prize.id) || PRIZES[PRIZES.length - 1];
          setTargetPrize(prize);
          setPhase('revealing');
          if (prize.won) {
            setShowConfetti(true);
            playWinSound();
          } else {
            playLoseSound();
          }
          setTimeout(() => setPhase('result'), 800);
          return;
        }
        setError(data.error || 'حدث خطأ. حاول مرة أخرى.');
        setPhase('form');
        return;
      }

      const prize = PRIZES.find(p => p.id === data.prize.id) || PRIZES[PRIZES.length - 1];
      setTargetPrize(prize);

      setTimeout(() => setPhase('spinning'), 800);
    } catch {
      setError('خطأ في الاتصال. تحقق من الإنترنت وحاول مرة أخرى.');
      setPhase('form');
    }
  }, [phone]);

  const handleSpinStart = useCallback(() => {}, []);

  const handleSpinEnd = useCallback((prize: PrizeDef) => {
    setPhase('revealing');
    if (prize.won) {
      setShowConfetti(true);
      playWinSound();
    } else {
      playLoseSound();
    }
    setTimeout(() => setPhase('result'), 800);
  }, []);

  const prizeInfo = targetPrize ? getPrizeInfo(targetPrize) : null;

  // ── Form Phase ────────────────────────────────────
  const renderForm = () => (
    <motion.div
      key="form"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-6 w-full max-w-md mx-auto px-4"
    >
      {/* Eid Countdown */}
      <div className="text-center mb-2">
        <p className="text-sm mb-3" style={{ color: 'rgba(240, 201, 135, 0.8)' }}>⏰ العد التنازلي لعيد الأضحى</p>
        <div className="flex items-center justify-center gap-2 sm:gap-3">
          {[
            { value: timeLeft.days, label: 'يوم' },
            { value: timeLeft.hours, label: 'ساعة' },
            { value: timeLeft.minutes, label: 'دقيقة' },
            { value: timeLeft.seconds, label: 'ثانية' },
          ].map((item) => (
            <div key={item.label} className="flex flex-col items-center">
              <div
                className="text-2xl sm:text-3xl font-bold tabular-nums"
                style={{
                  color: '#FFD700',
                  background: 'rgba(255, 215, 0, 0.1)',
                  border: '1px solid rgba(255, 215, 0, 0.3)',
                  borderRadius: '12px',
                  padding: '8px 12px',
                  minWidth: '60px',
                  textAlign: 'center',
                }}
              >
                {String(item.value).padStart(2, '0')}
              </div>
              <span className="text-xs mt-1.5" style={{ color: 'rgba(240, 201, 135, 0.6)' }}>{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Game Card */}
      <div
        className="w-full rounded-2xl p-6 sm:p-8 backdrop-blur-xl"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 248, 240, 0.08) 0%, rgba(212, 165, 116, 0.05) 100%)',
          border: '1px solid rgba(212, 165, 116, 0.2)',
          boxShadow: '0 25px 50px rgba(0, 0, 0, 0.3)',
        }}
      >
        {/* Title */}
        <div className="text-center mb-8">
          <div className="text-5xl mb-3 animate-float">🐑</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ color: '#F0C987' }}>
            ۳لوش
          </h1>
          <p className="text-base sm:text-lg" style={{ color: 'rgba(240, 201, 135, 0.7)' }}>
            العب واربح خروف للأضحية!
          </p>
        </div>

        {/* Phone input - the only field */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2 text-center" style={{ color: 'rgba(240, 201, 135, 0.8)' }}>
              📱 أدخل رقم هاتفك
            </label>
            <input
              ref={phoneInputRef}
              type="tel"
              inputMode="numeric"
              value={phone}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').slice(0, 8);
                setPhone(val);
                if (error) setError('');
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && phone.length === 8) handleSubmit();
              }}
              placeholder="22113344"
              className="w-full px-5 py-4 rounded-2xl text-xl text-center tracking-[0.3em] font-bold placeholder:text-gray-600 placeholder:tracking-[0.3em] placeholder:font-normal placeholder:text-sm transition-all focus:outline-none"
              style={{
                background: 'rgba(255, 248, 240, 0.05)',
                border: phone.length === 8
                  ? '2px solid rgba(39, 174, 96, 0.6)'
                  : '1px solid rgba(212, 165, 116, 0.2)',
                color: phone.length === 8 ? '#4ade80' : '#FFF8F0',
                boxShadow: phone.length === 8
                  ? '0 0 20px rgba(39, 174, 96, 0.15)'
                  : 'none',
              }}
              dir="ltr"
              maxLength={8}
              autoComplete="tel"
            />
            <div className="flex items-center justify-center gap-1 mt-2">
              {Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="w-1.5 h-1.5 rounded-full transition-colors duration-200"
                  style={{
                    backgroundColor: i < phone.length ? '#D4A574' : 'rgba(212, 165, 116, 0.2)',
                  }}
                />
              ))}
            </div>
          </div>

          {/* Error */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="px-4 py-2.5 rounded-xl text-sm text-center"
                style={{
                  background: 'rgba(231, 76, 60, 0.15)',
                  border: '1px solid rgba(231, 76, 60, 0.3)',
                  color: '#e74c3c',
                }}
              >
                {error}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Submit Button */}
          <button
            onClick={handleSubmit}
            disabled={phone.length !== 8 || phase === 'loading'}
            className="w-full py-4 rounded-2xl text-lg font-bold transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:scale-100"
            style={{
              background: phone.length === 8
                ? 'linear-gradient(135deg, #D4A574 0%, #F0C987 50%, #D4A574 100%)'
                : 'linear-gradient(135deg, rgba(212, 165, 116, 0.3) 0%, rgba(240, 201, 135, 0.3) 100%)',
              backgroundSize: '200% 200%',
              color: '#0A1628',
              boxShadow: phone.length === 8
                ? '0 4px 20px rgba(212, 165, 116, 0.5)'
                : 'none',
            }}
          >
            {phase === 'loading' ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-5 h-5 border-2 border-gray-800 border-t-transparent rounded-full animate-spin" />
                جاري التحميل...
              </span>
            ) : (
              '🎰 ابدأ اللعبة!'
            )}
          </button>
        </div>
      </div>

      {/* Stats */}
      {stats && stats.total > 0 && (
        <div className="text-center">
          <p className="text-xs" style={{ color: 'rgba(240, 201, 135, 0.5)' }}>
            📊 {stats.total} مشاركة | 🏆 {stats.winners} فائز
          </p>
        </div>
      )}
    </motion.div>
  );

  // ── Spinning Phase ────────────────────────────────
  const renderSpinning = () => (
    <motion.div
      key="spinning"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center gap-4 w-full"
    >
      <div className="text-center mb-2">
        <h2 className="text-xl sm:text-2xl font-bold mb-1" style={{ color: '#F0C987' }}>
          🎰 السحب جاري!
        </h2>
        <p className="text-sm" style={{ color: 'rgba(240, 201, 135, 0.6)' }}>
          شاهد الأيقونات تتوقف على جائزتك
        </p>
      </div>

      <div className="w-full px-2">
        <CardStrip
          targetPrize={targetPrize}
          onSpinStart={handleSpinStart}
          onSpinEnd={handleSpinEnd}
          isActive={phase === 'spinning'}
        />
      </div>

      <div className="flex flex-wrap items-center justify-center gap-3 mt-4">
        {PRIZES.map((p) => (
          <div key={p.id} className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs" style={{
            background: `${p.gradientFrom}22`,
            border: `1px solid ${p.borderColor}44`,
          }}>
            <span>{p.emoji}</span>
            <span style={{ color: p.borderColor }}>{p.name}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );

  // ── Result Phase ──────────────────────────────────
  const renderResult = () => {
    if (!prizeInfo) return null;
    const isWin = targetPrize.won;

    return (
      <motion.div
        key="result"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: 'spring', duration: 0.6 }}
        className="flex flex-col items-center gap-6 w-full max-w-md mx-auto px-4"
      >
        <div
          className="w-full rounded-2xl p-6 sm:p-8 text-center backdrop-blur-xl"
          style={{
            background: isWin
              ? `linear-gradient(135deg, ${targetPrize.gradientFrom}22 0%, ${targetPrize.gradientTo}22 100%)`
              : 'linear-gradient(135deg, rgba(255, 248, 240, 0.05) 0%, rgba(107, 114, 128, 0.05) 100%)',
            border: `2px solid ${isWin ? targetPrize.borderColor + '66' : 'rgba(107, 114, 128, 0.3)'}`,
            boxShadow: isWin
              ? `0 0 40px ${targetPrize.borderColor}22, 0 25px 50px rgba(0, 0, 0, 0.3)`
              : '0 25px 50px rgba(0, 0, 0, 0.3)',
          }}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2, stiffness: 200 }}
            className="text-7xl sm:text-8xl mb-4"
          >
            {targetPrize.emoji}
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xl sm:text-2xl font-bold mb-2"
            style={{ color: isWin ? '#F0C987' : '#9CA3AF' }}
          >
            {prizeInfo.title}
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-sm sm:text-base mb-2"
            style={{ color: 'rgba(240, 201, 135, 0.7)' }}
          >
            {prizeInfo.subtitle}
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="text-xs mb-6"
            style={{ color: 'rgba(240, 201, 135, 0.5)' }}
          >
            {prizeInfo.description}
          </motion.p>

          {/* QR Code */}
          {isWin && qrCode && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.8 }}
              className="flex flex-col items-center gap-2 mb-6"
            >
              <p className="text-xs font-medium" style={{ color: 'rgba(240, 201, 135, 0.7)' }}>
                شارك اللعبة مع أصدقائك!
              </p>
              <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.95)' }}>
                <img src={qrCode} alt="QR Code" className="w-32 h-32 sm:w-40 sm:h-40" />
              </div>
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="flex flex-col gap-3"
          >
            <button
              onClick={() => {
                const text = isWin
                  ? `🐑 لقد ربحت ${targetPrize.name} في لعبة ۳لوش! جرب حظك أيضاً!`
                  : `💨 شاركت في لعبة ۳لوش للأضحية. جرب حظك أيضاً!`;
                if (navigator.share) {
                  navigator.share({ title: '۳لوش - لعبة الأضحية', text, url: window.location.href });
                } else {
                  navigator.clipboard.writeText(text + ' ' + window.location.href);
                }
              }}
              className="w-full py-3 rounded-xl text-sm font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
              style={{
                background: 'rgba(26, 107, 60, 0.3)',
                border: '1px solid rgba(26, 107, 60, 0.5)',
                color: '#F0C987',
              }}
            >
              📤 شارك مع أصدقائك
            </button>
          </motion.div>
        </div>

        {stats && stats.total > 0 && (
          <div className="text-center">
            <p className="text-xs" style={{ color: 'rgba(240, 201, 135, 0.4)' }}>
              📊 {stats.total} مشاركة | 🏆 {stats.winners} فائز
            </p>
          </div>
        )}
      </motion.div>
    );
  };

  // ── Loading Phase ─────────────────────────────────
  const renderLoading = () => (
    <motion.div
      key="loading"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center gap-6 py-20"
    >
      <div className="relative">
        <div className="w-20 h-20 rounded-full border-4 border-transparent animate-spin" style={{
          borderTopColor: '#FFD700',
          borderRightColor: 'rgba(255, 215, 0, 0.3)',
        }} />
        <div className="absolute inset-0 flex items-center justify-center text-3xl">🐑</div>
      </div>
      <p className="text-lg font-medium" style={{ color: '#F0C987' }}>
        جاري تحضير السحب...
      </p>
    </motion.div>
  );

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden" style={{ background: '#0A1628' }}>
      {/* Background layers */}
      <div className="fixed inset-0 z-0">
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at top center, rgba(26, 107, 60, 0.15) 0%, transparent 50%), radial-gradient(ellipse at bottom right, rgba(212, 165, 116, 0.1) 0%, transparent 50%), linear-gradient(180deg, #0A1628 0%, #0D1F3C 50%, #0A1628 100%)',
          }}
        />
        <div className="absolute inset-0 islamic-pattern opacity-50" />
      </div>

      <DecorativeStars />
      <Confetti isActive={showConfetti} duration={5000} particleCount={80} />

      {/* Header */}
      <header className="relative z-10 pt-6 pb-2 px-4">
        <div className="flex items-center justify-center gap-2">
          <span className="text-2xl">☪️</span>
          <h1 className="text-lg sm:text-xl font-bold" style={{ color: '#F0C987' }}>
            ۳لوش
          </h1>
          <span className="text-2xl">🐑</span>
        </div>
        <p className="text-xs text-center mt-1" style={{ color: 'rgba(240, 201, 135, 0.5)' }}>
          لعبة عيد الأضحية 2025
        </p>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center py-6">
        <AnimatePresence mode="wait">
          {phase === 'form' && renderForm()}
          {phase === 'loading' && renderLoading()}
          {(phase === 'spinning' || phase === 'revealing') && renderSpinning()}
          {phase === 'result' && renderResult()}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-4 px-4 mt-auto">
        <div className="max-w-md mx-auto text-center">
          <div className="flex items-center justify-center gap-4 mb-2">
            <div className="h-px flex-1" style={{ background: 'rgba(212, 165, 116, 0.15)' }} />
            <span className="text-xs" style={{ color: 'rgba(240, 201, 135, 0.3)' }}>☪</span>
            <div className="h-px flex-1" style={{ background: 'rgba(212, 165, 116, 0.15)' }} />
          </div>
          <p className="text-xs mb-1" style={{ color: 'rgba(240, 201, 135, 0.3)' }}>
            كل عام وأنتم بخير
          </p>
          <p className="text-xs" style={{ color: 'rgba(240, 201, 135, 0.2)' }}>
            © 2025 ۳لوش - جميع الحقوق محفوظة
          </p>
        </div>
      </footer>
    </div>
  );
}
