import type { Metadata } from "next";
import { Changa } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const changa = Changa({
  variable: "--font-changa",
  subsets: ["arabic", "latin"],
  weight: ["200", "300", "400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "۳لوش - لعبة الأضحية | 3alouch - Eid Game",
  description: "العب واربح خروف للأضحية! شارك في لعبة ۳لوش واختبر حظك. Play and win a sheep for Eid al-Adha!",
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "۳لوش - لعبة الأضحية",
    description: "العب واربح خروف للأضحية!",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${changa.variable} font-[family-name:var(--font-changa)] antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
