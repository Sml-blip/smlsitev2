'use client';

import React, { useEffect, useRef, useMemo } from 'react';

interface ConfettiPiece {
  id: number;
  x: number;
  size: number;
  color: string;
  delay: number;
  duration: number;
  rotation: number;
  shape: 'square' | 'circle' | 'star';
}

const COLORS = [
  '#FFD700', '#F0C987', '#D4A574', '#1A6B3C',
  '#A855F7', '#EC4899', '#E74C3C', '#FF6B6B',
  '#4ECDC4', '#45B7D1', '#FFA500', '#FF69B4',
];

function StarShape({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </svg>
  );
}

interface ConfettiProps {
  isActive: boolean;
  duration?: number;
  particleCount?: number;
}

export default function Confetti({ isActive, duration = 4000, particleCount = 60 }: ConfettiProps) {
  const [visible, setVisible] = React.useState(false);
  const pieces = useMemo(() => {
    const newPieces: ConfettiPiece[] = [];
    for (let i = 0; i < particleCount; i++) {
      newPieces.push({
        id: i,
        x: Math.random() * 100,
        size: 6 + Math.random() * 12,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        delay: Math.random() * 1500,
        duration: 2000 + Math.random() * 3000,
        rotation: Math.random() * 360,
        shape: (['square', 'circle', 'star'] as const)[Math.floor(Math.random() * 3)],
      });
    }
    return newPieces;
  }, [particleCount]);

  useEffect(() => {
    if (isActive) {
      setVisible(true);
      const timer = setTimeout(() => setVisible(false), duration);
      return () => clearTimeout(timer);
    } else {
      setVisible(false);
    }
  }, [isActive, duration]);

  if (!visible) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {pieces.map((piece) => (
        <div
          key={piece.id}
          className="confetti-piece"
          style={{
            left: `${piece.x}%`,
            animationDuration: `${piece.duration}ms`,
            animationDelay: `${piece.delay}ms`,
          }}
        >
          {piece.shape === 'star' ? (
            <StarShape size={piece.size} color={piece.color} />
          ) : (
            <div
              style={{
                width: piece.size,
                height: piece.size,
                backgroundColor: piece.color,
                borderRadius: piece.shape === 'circle' ? '50%' : '2px',
                transform: `rotate(${piece.rotation}deg)`,
              }}
            />
          )}
        </div>
      ))}
    </div>
  );
}
