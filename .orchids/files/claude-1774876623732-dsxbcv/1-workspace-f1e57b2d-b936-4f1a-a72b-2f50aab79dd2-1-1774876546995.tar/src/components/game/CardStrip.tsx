'use client';

import React, { useEffect, useRef, useCallback, useState, useMemo } from 'react';
import gsap from 'gsap';
import { playTick, playHeavyTick, playRevealSound, playDrumRoll, initAudio } from '@/lib/audio';

export interface PrizeDef {
  id: string;
  emoji: string;
  name: string;
  tier: 'legendary' | 'rare' | 'uncommon' | 'common' | 'none';
  gradientFrom: string;
  gradientTo: string;
  borderColor: string;
  textColor: string;
  weight: number;
  won: boolean;
}

export const PRIZES: PrizeDef[] = [
  {
    id: 'sheep', emoji: '🐑', name: 'خروف',
    tier: 'legendary',
    gradientFrom: '#B8860B', gradientTo: '#FFD700',
    borderColor: '#FFD700', textColor: '#4a2800',
    weight: 1, won: true,
  },
  {
    id: 'gift', emoji: '🎁', name: 'هدية',
    tier: 'rare',
    gradientFrom: '#6B21A8', gradientTo: '#A855F7',
    borderColor: '#A855F7', textColor: '#ffffff',
    weight: 4, won: true,
  },
  {
    id: 'coffee', emoji: '☕', name: 'قهوة',
    tier: 'uncommon',
    gradientFrom: '#92400E', gradientTo: '#D97706',
    borderColor: '#D97706', textColor: '#ffffff',
    weight: 10, won: true,
  },
  {
    id: 'sweets', emoji: '🍬', name: 'حلوى',
    tier: 'common',
    gradientFrom: '#9D174D', gradientTo: '#EC4899',
    borderColor: '#EC4899', textColor: '#ffffff',
    weight: 20, won: true,
  },
  {
    id: 'nothing', emoji: '💨', name: 'لا شيء',
    tier: 'none',
    gradientFrom: '#374151', gradientTo: '#4B5563',
    borderColor: '#6B7280', textColor: '#9CA3AF',
    weight: 65, won: false,
  },
];

function weightedRandom(): PrizeDef {
  const totalWeight = PRIZES.reduce((sum, p) => sum + p.weight, 0);
  let r = Math.random() * totalWeight;
  for (const prize of PRIZES) {
    r -= prize.weight;
    if (r <= 0) return prize;
  }
  return PRIZES[PRIZES.length - 1];
}

interface CardStripProps {
  targetPrize: PrizeDef;
  onSpinStart: () => void;
  onSpinEnd: (finalPrize: PrizeDef) => void;
  isActive: boolean;
}

const CARD_WIDTH_DESKTOP = 110;
const CARD_HEIGHT_DESKTOP = 140;
const CARD_WIDTH_MOBILE = 85;
const CARD_HEIGHT_MOBILE = 110;
const GAP = 6;
const TOTAL_CARDS = 250;
const WINNER_INDEX = 200; // Place the winning card near the end

export default function CardStrip({ targetPrize, onSpinStart, onSpinEnd, isActive }: CardStripProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const stripRef = useRef<HTMLDivElement>(null);
  const indicatorRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<gsap.core.Timeline | null>(null);
  const lastTickIndex = useRef<number>(-1);
  const [cardWidth, setCardWidth] = useState(CARD_WIDTH_MOBILE);
  const [isComplete, setIsComplete] = useState(false);
  const [winnerCardIndex, setWinnerCardIndex] = useState<number>(WINNER_INDEX);

  // Responsive card sizing
  useEffect(() => {
    const updateSize = () => {
      setCardWidth(window.innerWidth >= 640 ? CARD_WIDTH_DESKTOP : CARD_WIDTH_MOBILE);
    };
    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  // Generate card data - memoized
  const cards = useMemo(() => {
    const generated: PrizeDef[] = [];
    for (let i = 0; i < TOTAL_CARDS; i++) {
      if (i === WINNER_INDEX) {
        generated.push(targetPrize);
      } else {
        // Avoid placing the target prize too close to the winner
        let card: PrizeDef;
        let attempts = 0;
        do {
          card = weightedRandom();
          attempts++;
        } while (
          card.id === targetPrize.id && targetPrize.tier === 'legendary' &&
          Math.abs(i - WINNER_INDEX) < 10 &&
          attempts < 20
        );
        generated.push(card);
      }
    }
    return generated;
  }, [targetPrize]);

  const totalCardStep = cardWidth + GAP;

  // Main animation logic
  const startSpin = useCallback(() => {
    if (!stripRef.current || !containerRef.current || timelineRef.current) return;

    initAudio();
    playDrumRoll();

    const containerWidth = containerRef.current.offsetWidth;
    // Target: align winner card center with container center
    const targetX = -(winnerCardIndex * totalCardStep) + (containerWidth / 2) - (cardWidth / 2);
    // Start position: show first few cards coming from the right
    const startX = containerWidth / 2 - (cardWidth / 2) - totalCardStep;

    // Set initial position
    gsap.set(stripRef.current, { x: startX });

    lastTickIndex.current = -1;
    setIsComplete(false);
    onSpinStart();

    // Create the main timeline
    const tl = gsap.timeline({
      onComplete: () => {
        setIsComplete(true);
        playRevealSound();
        // Small delay before showing result for dramatic effect
        setTimeout(() => {
          onSpinEnd(targetPrize);
        }, 1200);
      },
    });

    // Phase 1: Fast scroll through cards (0-70% of animation)
    tl.to(stripRef.current, {
      x: targetX + 300, // Almost to final position
      duration: 5,
      ease: 'power2.inOut',
      onUpdate: () => {
        if (!stripRef.current || !containerRef.current) return;
        const currentX = gsap.getProperty(stripRef.current, 'x') as number;
        const normalizedX = -currentX + (containerWidth / 2) - (cardWidth / 2);
        const currentIndex = Math.round(normalizedX / totalCardStep);
        
        if (currentIndex !== lastTickIndex.current && currentIndex >= 0 && currentIndex < cards.length) {
          lastTickIndex.current = currentIndex;
          const card = cards[currentIndex];
          if (card.tier === 'legendary' || card.tier === 'rare') {
            playHeavyTick();
          } else {
            playTick(600 + Math.random() * 400);
          }
        }
      },
    });

    // Phase 2: Slow dramatic approach (70-100%)
    tl.to(stripRef.current, {
      x: targetX,
      duration: 4,
      ease: 'power4.out',
      onUpdate: () => {
        if (!stripRef.current || !containerRef.current) return;
        const currentX = gsap.getProperty(stripRef.current, 'x') as number;
        const normalizedX = -currentX + (containerWidth / 2) - (cardWidth / 2);
        const currentIndex = Math.round(normalizedX / totalCardStep);

        if (currentIndex !== lastTickIndex.current && currentIndex >= 0 && currentIndex < cards.length) {
          lastTickIndex.current = currentIndex;
          const card = cards[currentIndex];
          // Vary tick pitch based on proximity to winner
          const dist = Math.abs(currentIndex - winnerCardIndex);
          if (dist <= 3) {
            playTick(1000 + Math.random() * 200); // Higher pitch near winner
          } else if (card.tier === 'legendary' || card.tier === 'rare') {
            playHeavyTick();
          } else {
            playTick(600 + Math.random() * 400);
          }
        }
      },
    });

    // Phase 3: Small bounce past and back for extra tension
    tl.to(stripRef.current, {
      x: targetX - totalCardStep * 0.3,
      duration: 0.3,
      ease: 'power2.in',
    })
    .to(stripRef.current, {
      x: targetX + totalCardStep * 0.15,
      duration: 0.3,
      ease: 'power2.out',
    })
    .to(stripRef.current, {
      x: targetX,
      duration: 0.5,
      ease: 'elastic.out(1, 0.5)',
    });

    timelineRef.current = tl;
  }, [cardWidth, totalCardStep, winnerCardIndex, cards, targetPrize, onSpinStart, onSpinEnd]);

  useEffect(() => {
    if (isActive && stripRef.current) {
      // Defer to next frame to avoid synchronous setState in effect
      const raf = requestAnimationFrame(() => startSpin());
      return () => {
        cancelAnimationFrame(raf);
        if (timelineRef.current) {
          timelineRef.current.kill();
          timelineRef.current = null;
        }
      };
    }
    return () => {};
  }, [isActive, startSpin]);

  const cardHeight = cardWidth === CARD_WIDTH_DESKTOP ? CARD_HEIGHT_DESKTOP : CARD_HEIGHT_MOBILE;

  return (
    <div className="relative w-full select-none" style={{ direction: 'ltr' }}>
      {/* Top fade overlay */}
      <div
        className="absolute top-0 left-0 right-0 h-8 z-10 pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, #0A1628 0%, transparent 100%)',
        }}
      />
      {/* Bottom fade overlay */}
      <div
        className="absolute bottom-0 left-0 right-0 h-8 z-10 pointer-events-none"
        style={{
          background: 'linear-gradient(to top, #0A1628 0%, transparent 100%)',
        }}
      />
      {/* Left fade */}
      <div
        className="absolute top-0 bottom-0 left-0 w-16 z-10 pointer-events-none"
        style={{
          background: 'linear-gradient(to right, #0A1628 0%, transparent 100%)',
        }}
      />
      {/* Right fade */}
      <div
        className="absolute top-0 bottom-0 right-0 w-16 z-10 pointer-events-none"
        style={{
          background: 'linear-gradient(to left, #0A1628 0%, transparent 100%)',
        }}
      />

      {/* Center indicator */}
      <div
        ref={indicatorRef}
        className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 z-20 pointer-events-none"
      >
        <div className="flex flex-col items-center h-full justify-center">
          {/* Top arrow */}
          <div className={`text-2xl ${isActive && !isComplete ? 'indicator-pulse' : ''}`} style={{ color: '#FFD700' }}>
            ▼
          </div>
          {/* Indicator line */}
          <div
            className="w-1 rounded-full flex-1 my-1"
            style={{
              background: 'linear-gradient(to bottom, #FFD700 0%, rgba(255, 215, 0, 0.3) 50%, #FFD700 100%)',
              boxShadow: '0 0 10px rgba(255, 215, 0, 0.5), 0 0 20px rgba(255, 215, 0, 0.3)',
            }}
          />
          {/* Bottom arrow */}
          <div className={`text-2xl ${isActive && !isComplete ? 'indicator-pulse' : ''}`} style={{ color: '#FFD700' }}>
            ▲
          </div>
        </div>
      </div>

      {/* Card strip container */}
      <div
        ref={containerRef}
        className="overflow-hidden w-full"
        style={{ height: cardHeight + 20 }}
      >
        <div
          ref={stripRef}
          className="flex items-center"
          style={{
            gap: `${GAP}px`,
            willChange: 'transform',
            padding: '10px 0',
          }}
        >
          {cards.map((card, index) => {
            const isWinner = index === winnerCardIndex;
            return (
              <div
                key={index}
                className={`flex-shrink-0 rounded-xl flex flex-col items-center justify-center gap-1 transition-all duration-300 relative overflow-hidden ${
                  isComplete && isWinner ? 'winner-glow scale-110 z-30' : ''
                }`}
                style={{
                  width: `${cardWidth}px`,
                  height: `${cardHeight}px`,
                  background: `linear-gradient(135deg, ${card.gradientFrom} 0%, ${card.gradientTo} 100%)`,
                  border: isWinner && isComplete
                    ? `3px solid ${card.borderColor}`
                    : `2px solid ${card.borderColor}66`,
                  boxShadow: isWinner && isComplete
                    ? `0 0 30px ${card.borderColor}88, 0 0 60px ${card.borderColor}44`
                    : '0 2px 8px rgba(0,0,0,0.3)',
                }}
              >
                {/* Shimmer overlay when spinning */}
                {isActive && !isComplete && (
                  <div className="absolute inset-0 card-shimmer" />
                )}
                {/* Tier indicator dot */}
                <div
                  className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full"
                  style={{
                    backgroundColor:
                      card.tier === 'legendary' ? '#FFD700' :
                      card.tier === 'rare' ? '#A855F7' :
                      card.tier === 'uncommon' ? '#D97706' :
                      card.tier === 'common' ? '#EC4899' : '#6B7280',
                    boxShadow:
                      card.tier === 'legendary' ? '0 0 6px #FFD700' :
                      card.tier === 'rare' ? '0 0 6px #A855F7' : 'none',
                  }}
                />
                {/* Emoji */}
                <span className="text-3xl sm:text-4xl drop-shadow-lg" style={{ filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))' }}>
                  {card.emoji}
                </span>
                {/* Name */}
                <span
                  className="text-xs sm:text-sm font-bold leading-tight text-center px-1"
                  style={{ color: card.textColor }}
                >
                  {card.name}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Speed indicator during animation */}
      {isActive && !isComplete && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-20">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full" style={{ background: 'rgba(0,0,0,0.6)' }}>
            <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
            <span className="text-xs text-yellow-400 font-medium">جاري السحب...</span>
          </div>
        </div>
      )}
    </div>
  );
}
